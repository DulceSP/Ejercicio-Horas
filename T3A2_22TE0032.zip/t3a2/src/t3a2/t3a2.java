package t3a2;


public class t3a2 {
    private int horaInicio;
    private int horaFinal;
    private String diaInicio;
    private String diaFinal;
    
    public t3a2(){}

    public t3a2(int horaInicio, int horaFinal, String diaInicio, String diaFinal) {
        this.horaInicio = horaInicio;
        this.horaFinal = horaFinal;
        this.diaInicio = diaInicio;
        this.diaFinal = diaFinal;
    }
    
    

    public int getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(int horaInicio) {
        this.horaInicio = horaInicio;
    }

    public int getHoraFinal() {
        return horaFinal;
    }

    public void setHoraFinal(int horaFinal) {
        this.horaFinal = horaFinal;
    }

    public String getDiaInicio() {
        return diaInicio;
    }

    public void setDiaInicio(String diaInicio) {
        this.diaInicio = diaInicio;
    }

    public String getDiaFinal() {
        return diaFinal;
    }

    public void setDiaFinal(String diaFinal) {
        this.diaFinal = diaFinal;
    }
    
    @Override
    public String toString (){
     String mensaje = "Han transcurrido " +  " desde la(s) " + horaInicio+ " del día "  + diaInicio + " hasta la " + horaFinal " del día " diaFinal ;
             
             return mensaje;
    }
}
